# HUGO / JARVIS v7.0.0

Еден локален, автономен runtime. **Без API клучеви.** За веб користи твојот Chrome со твоите логина.

## Што е ново во 7.0.0
- **Реална контрола на фајлови и папки:** file_write/read/edit/append/list/tree/search/copy/move/delete/stat/hash + мапирање патеки Windows ↔ WSL. Секое пишување се верификува со читање назад.
- **Windows + WSL контрола:** PowerShell, CMD, bash, WSL дистрибуции и команди, процеси, апликации, прозорци, clipboard, слика од екран, тон, говор (SAPI), нотификации.
- **Chrome со твојата најава:** chrome:attach најпрво се поврзува на постоечка debug сесија, инаку стартува Chrome со копија од твојот профил. HUGO не зачувува лозинки и cookies.
- **Facebook без Facebook API:** fb_open, fb_feed_read, fb_search, fb_write_post, fb_publish — со верификација дека постот е објавен.
- **YouTube контрола:** yt_open/search/play/pause/resume/next/volume/now_playing — проверено во самиот плеер (video.paused, currentTime, volume).
- **Вид без клуч:** vision_page, vision_ask, vision_screen — жив DOM + геометрија + OCR (ако има tesseract).
- **Планирање без лажен успех:** рутер за македонски/англиски што избира вистински алатки; непознат чекор е `blocked` и никогаш не се пријавува како успех.
- **Верификација и потврди:** cognition/verify.js независно проверува; деструктивни и профилни акции бараат изрична потврда.
- **Распоред со retry:** закажаните задачи повторуваат со backoff и пријавуваат дали резултатот е потврден.
- **Синхронизација на регистарот:** npm run registry:sync и npm run registry:check.

## Стартување
```bash
node scripts/cli/hugo.js doctor
node scripts/cli/hugo.js host
node scripts/cli/hugo.js chrome:attach
node scripts/cli/hugo.js exec "Направи test.txt со Hello"
node scripts/cli/hugo.js exec "Отвори Facebook"
node scripts/cli/hugo.js exec "Отвори YouTube и пушти Imagine Dragons"
node scripts/cli/hugo.js start
node scripts/tests/run-all.js && node scripts/tests/jarvis.js
```
